<?php
$link = mysqli_connect('localhost', 'root', '', 'drill');
//$db = mysql_select_db('gallery', $link);
?>