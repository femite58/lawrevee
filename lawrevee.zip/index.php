<?php
session_start();
include("connect.php");
  include("functions.php");

$sqlgnip = "SELECT * FROM blog WHERE publish=1";
    $querygnip = mysqli_query($link,$sqlgnip);
    while($fchgnip = mysqli_fetch_assoc($querygnip)){
        
        $bid[]= $fchgnip["id"];
       
       
}
$strp = 0;
$stpp = $strp-12;
$pg = 1;

if(isset($_GET["pg"])){
	$strp = sanitizeInput($_GET["pg"])*12;
	$stpp = $strp-12;
	$pg = sanitizeInput($_GET["pg"]);
}

?> 
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Lawrevee Homes</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,700,900|Roboto+Mono:300,400,500"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/mediaelementplayer.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/fl-bigmug-line.css">
    
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
    
  </head>
  <body>
  
  <div class="site-loader"></div>
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->

   <?php include "header.php"; ?>
    </div>

    <div class="slide-one-item home-slider owl-carousel">

      <div class="site-blocks-cover overlay" style="background-image: url(images/hero_bg_1.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-10">
           
              <h2 class="mb-2 text-white">LANDS & REAL ESTATE TRADING EXCHANGE </h2>
              <p class="mb-5"><strong class="h2 text-success font-weight-bold"></strong></p>
				<p><a href="lands.php" class="btn btn-white btn-outline-white py-3 px-5 rounded-0 btn-2 mb-2">Lands <span class="icon-arrow_forward"></span></a> <a href="investments.php" class="btn btn-white btn-outline-white py-3 px-5 rounded-0 btn-2 mb-2">Investments <span class="icon-arrow_forward"></span></a></p>
            </div>
          </div>
        </div>
      </div>  

      <div class="site-blocks-cover overlay" style="background-image: url(images/hero_bg_2.jpg);" data-aos="fade" data-stellar-background-ratio="0.5">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-10">
             
              <h2 class="mb-2 text-white">LANDS & REAL ESTATE TRADING EXCHANGE </h2>
              <p class="mb-5"><strong class="h2 text-success font-weight-bold"></strong></p>
				<p><a href="lands.php" class="btn btn-white btn-outline-white py-3 px-5 rounded-0 btn-2 mb-2">Lands <span class="icon-arrow_forward"></span></a> <a href="investments.php" class="btn btn-white btn-outline-white py-3 px-5 rounded-0 btn-2 mb-2">Investments <span class="icon-arrow_forward"></span></a></p>
            </div>
          </div>
        </div>
      </div>  

    </div>


    <div class="site-section">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 text-center">
            <div class="site-section-title">
              <h2>Why Choose Us?</h2>
            </div>
            <p>Lawrevee  ventures ltd has been operating in the property market in Nigeria for more than 2 decades. As property manager we have real estate assets worth over 50 billion naira </p>
          </div>
        </div>

        <div class="row">
          <div class="col-md-6">
            <a href="#" class="service text-center">
              <span class="icon flaticon-house"></span>
              <h2 class="service-heading">Purchase Property</h2>
              <p>View our list of Real Estate properties, available for outright purcahse at strategic locations in Nigeria.</p>
              <p class="text-center"><a href="lands.php" class="btn btn-success btn-outline-white py-3 px-5 rounded-0 btn-2">Purchase Now</a></p>
            </a>
          </div>
          <div class="col-md-6">
            <a href="#" class="service text-center">
              <span class="icon flaticon-sold"></span>
              <h2 class="service-heading">Buy and Sell (Investment)</h2>
              <p>Buy and sell properties (land & homes) online at the comfort of your home. Return on investment as high as 60% per annum </p>
				<p class="text-center"><a href="createaccount.php" class="btn btn-info btn-outline-white py-3 px-5 rounded-0 btn-2">Register Now</a></p>
            </a>
          </div>
         
        </div>
      </div>
    </div>

    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center">
            <div class="site-section-title">
              <h2>Recent News</h2>
            </div>
            <p>Keep in touch with the latest news and offers available at Lawrevee Ventures.</p>
          </div>
        </div>
        <div class="row">
         		<?php
				if(!empty($bid)){
					$curps = count($bid)-($strp+1);
				for($i=$curps; $i>=0; $i--){
					 $pstg = getblogcontent($bid[$i]); 
					preg_match('/<img.+src=[\'"](?P<src>.+?)[\'"].*>/i', $pstg, $image); 
					?>
          <div class="col-md-6 col-lg-4 mb-4" data-aos="fade-up" data-aos-delay="100">
            <a href="readpost.php?rp=<?php echo getblogtopicurl($bid[$i]); ?>"><img src="<?php  echo $image['src'];
 ?>" alt="<?php echo getblogtopic($bid[$i]); ?>" alt="Image" class="img-fluid"></a>
            <div class="p-4 bg-white">
              <span class="d-block text-secondary small text-uppercase"><?php echo getblogdate($bid[$i]); ?></span>
              <h2 class="h5 text-black mb-3"><a href="readpost.php?rp=<?php echo getblogtopicurl($bid[$i]); ?>"><?php echo getblogtopic($bid[$i]); ?></a></h2>
              <p><?php echo strstr(getblogcontent($bid[$i]),"</p>", true); echo "..."; ?></p>
            </div>
          </div>
  <?php 
					if($i<=$curps-3){
				break;
			}
				 }
                   }?>
			 
        </div>

      </div>
    </div>

    
    

   <?php include "footer.php"; ?>
  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/mediaelement-and-player.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>
    
  </body>
</html>