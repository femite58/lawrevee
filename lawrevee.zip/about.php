<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Lawrevee &mdash; About</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito+Sans:200,300,400,700,900|Roboto+Mono:300,400,500"> 
    <link rel="stylesheet" href="fonts/icomoon/style.css">

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/jquery-ui.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/mediaelementplayer.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/fl-bigmug-line.css">
    
  
    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/style.css">
	
  </head>
  <body>
  <div class="site-loader"></div>
    
  
  <div class="site-wrap">

    <div class="site-mobile-menu">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div> <!-- .site-mobile-menu -->

     <?php include "header.php"; ?>
    </div>
	  
 <div class="site-blocks-cover inner-page-cover overlay" style="background-image: url(images/hero_bg_2.jpg); min-height:80px;" data-aos="fade" data-stellar-background-ratio="0.5">
      <div class="container">
        <div class="row "  style=" min-height:80px;">
          <div class="col-md-12">
           <br><br><br>
            <h4 class="text-white mt-5 text-center">About Us</h4>
          </div>
        </div>
      </div>
    </div>

    <div class="site-section site-section-sm bg-light">
      <div class="container">
		 <div class="row mb-5">
			 
				  <div class="col-sm-12">
	
<div class="bg-white widget border rounded">

              <h3 class="h4 text-black widget-title mb-3">MISSION</h3>
	<ul>
		<li>To achieve the vision of this organization lawrevee will make  available real estate assets i.e properties(land and buildings) for people to buy and sell for profit </li>
		<li>Lawrevee  will establish  an exchange with online presence  for the property market in Nigeria, where properties can be traded without physical possession  </li>
		<li>Lawrevee  will offer to sell the properties in the physical market for the real estate business owners that join our company 
		</li>
	</ul>
			 </div>
			 </div>
			 
		
		 <div class="col-lg-6">
	<div class="bg-white widget border rounded">
       <h3 class="h4 text-black widget-title mb-3">VISION</h3>
	<p>The vision of lawrevee real estate trading exchange is to offer opportunity to individuals that want to start real estate business with the goal of making profit </p>
			 </div>
			 </div>
			
		
	 <div class="col-lg-3">
		 <div class="bg-white widget border rounded">
	          <h3 class="h4 text-black widget-title mb-3">Our Objectives
</h3>
	<p>To make estate available for the average Nigerian with ease  </p>
			 </div>
			 </div>
			
	 <div class="col-lg-3">
	<div class="bg-white widget border rounded">
             <h3 class="h4 text-black widget-title mb-3">Our Core Value
</h3>
	<p>Integrity, Honesty and Efficiency </p>
			 </div>
			 </div>
			
	
			 
			 </div>
       
		  <div class="row  justify-content-center">
	
		 <div class="col-md-12 text-center">
            <div class="site-section-title">
              <h2>Why Choose Us?</h2>
            </div>
            <p>As one of the leading company in real estate industry, we are here to make a difference and set pace for others to follow. </p>
          </div>
			  
			  <div class="col-md-3 ">
				  <div class="bg-white widget border rounded">
            <div class="site-section-title">
				<h4><b>Over 20 years of expert experience </b></h4>
            </div>
            <p>We have been in real estate industry for over two decades, making impact and making dreams of people across Nigeria to become house owners reality </p>
          </div>
          </div>
			
			  
			  <div class="col-md-3 ">
				  <div class="bg-white widget border rounded">
            <div class="site-section-title">
				<h4><b>Strategic business plan  </b></h4>
            </div>
            <p>We are strategic in our service and products tailored to meet your exact taste and target market.
</p>
          </div>
          </div>
			  
			  <div class="col-md-3 ">
				  <div class="bg-white widget border rounded">
            <div class="site-section-title">
				<h4><b>Technology driven  </b></h4>
            </div>
            <p>We operate with global standard technology which makes us second to none as an indigenous company.
 </p>
          </div>  
          </div>  
			  <div class="col-md-3 ">
				  <div class="bg-white widget border rounded">
            <div class="site-section-title">
				<h4><b>Automated System   </b></h4>
            </div>
            <p>We have in-built technology driven system programmed that run on auto-pilot, making it easy to access every information at your finger tips.

 </p>
				  </div>
          </div>
			  
			  
			 </div>
			
        
      </div>
    </div>

    
      <?php include "footer.php"; ?>

  </div>

  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/mediaelement-and-player.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/jquery.countdown.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/bootstrap-datepicker.min.js"></script>
  <script src="js/aos.js"></script>

  <script src="js/main.js"></script>

  </body>
</html>